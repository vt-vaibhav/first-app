self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "213abc48b4b2d074fee255e4e22b1c98",
    "url": "/bmi-calculator/index.html"
  },
  {
    "revision": "b4aa88851593ac880bfa",
    "url": "/bmi-calculator/static/css/2.ae9e8b99.chunk.css"
  },
  {
    "revision": "4bcfdcfbb9a7b3947e21",
    "url": "/bmi-calculator/static/css/main.fce36487.chunk.css"
  },
  {
    "revision": "b4aa88851593ac880bfa",
    "url": "/bmi-calculator/static/js/2.0e5f39ad.chunk.js"
  },
  {
    "revision": "4bcfdcfbb9a7b3947e21",
    "url": "/bmi-calculator/static/js/main.64fa15ad.chunk.js"
  },
  {
    "revision": "9b25b4e690523b173542",
    "url": "/bmi-calculator/static/js/runtime~main.425d477f.js"
  }
]);